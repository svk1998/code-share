# Fridge Intelligence Data Platform

Production-grade, cost-effective batch lakehouse on GCP for smart-fridge
L1–L4 recognition events.

```
Fridge diffs → SmartThings → GCS landing/ → Validator (contract) → raw/
             → BigQuery LOAD JOB (free) → bronze → dbt → silver → gold
                                   quarantine/ + rejected_events (DLQ)
```

Design principles: batch-first (no Pub/Sub, no Dataflow, no Composer),
diffs-not-snapshots, medallion lakehouse, serverless scale-to-zero,
privacy by design (DPDP/GDPR), SLO-driven observability.

## Layout

| Path | What |
|---|---|
| `terraform/` | All infra: buckets, datasets, tables, Cloud Run jobs, Workflows, Scheduler, alerts |
| `services/validator` | Data-contract validation, landing/ → raw/ or quarantine/ |
| `services/loader` | BigQuery load jobs into `bronze.raw_events` |
| `services/enrichment` | Product resolution ladder: cache → vector → LLM batch |
| `services/erasure` | DPDP/GDPR deletion job driven by `ops.deletion_requests` |
| `dbt/` | silver (SCD2 items, events) + gold (features, cycles) models & tests |
| `workflows/pipeline.yaml` | Cloud Workflows DAG: validate → load → dbt → enrich |
| `scripts/` | Synthetic event generator for end-to-end testing |
| `docs/runbooks/` | Backfill and erasure runbooks |
| `local/` | DuckDB sandbox — run the whole pipeline with no GCP |

## Learn it locally first (no GCP)

```bash
pip install dbt-duckdb jsonschema
cd local && ./run_local.sh
```
Runs the whole pipeline on DuckDB + your filesystem in ~10s. See `local/README.md`.

## Quickstart (dev)

```bash
# 1. Infra
gcloud auth application-default login
make init && make apply ENV=dev

# 2. Build & push service images (Cloud Build)
gcloud builds submit services/validator --tag $REGION-docker.pkg.dev/$PROJECT/pipeline/validator
# ... repeat for loader / enrichment / erasure, or use scripts/build_all.sh

# 3. Synthetic data end-to-end
make synth-data

# 4. Trigger the pipeline once manually
gcloud workflows run fridge-pipeline --location=$REGION

# 5. dbt locally (CI runs it in Cloud Run)
cp dbt/profiles.yml.example ~/.dbt/profiles.yml   # edit project ids
make dbt-build ENV=dev
```

## Environments

`dev` / `stage` / `prod` are separate GCP projects. Select with
`make apply ENV=stage`. Retention, lifecycle and partition expiry are
policy-as-code in `terraform/modules/storage` and `modules/bigquery` —
change them via PR, never via console.

## SLOs

1. **Freshness** — gold updated ≤ 6 h after capture window
2. **Completeness** — daily volume within ±30% of 7-day median
3. **Quality** — 100% dbt test pass on silver

See `terraform/modules/monitoring` for the alert policies.
