# Architecture

```
Family Hub fridge ──(L1–L4 diffs)──► SmartThings cloud ──(gzip JSONL, 4–6h)──►
GCS landing/ ──► Validator (Cloud Run Job, JSON-Schema contract)
   ├── valid    ──► raw/device_id=…/date=…/  ──► BigQuery LOAD JOB (free) ──► bronze.raw_events
   └── invalid  ──► quarantine/ + bronze.rejected_events (DLQ)

bronze ──► dbt (Cloud Run Job) ──► silver (item_events dedup, fridge_items SCD2, product_catalog)
                                     ▲
        enrichment (Cloud Run Job) ──┘  cache → BQ vector search → LLM batch, write-back
silver ──► dbt ──► gold (household_features, replenishment_cycles, health_scores, segments)

Orchestration : Cloud Scheduler → Cloud Workflows → Cloud Run Jobs (scale-to-zero)
Governance    : ops.deletion_requests → nightly erasure job; Terraform retention/lifecycle
Observability : 3 SLOs (freshness, completeness, quality) + Cloud Monitoring alerts
```

## Why batch, not streaming

Fridge events have no real-time requirement. BigQuery **load jobs are free**,
so the main path avoids Pub/Sub and Dataflow entirely. A narrow streaming
path can be added later *only* for a specific real-time feature.

## Cost levers

- Diffs, not snapshots (10–20× volume reduction at the device)
- Physical storage billing on all datasets (3–5× cheaper for compressed JSON)
- `require_partition_filter = true` blocks runaway ad-hoc scans
- Cloud Workflows + Scheduler instead of Composer (saves ~$400/mo idle)
- On-demand BigQuery until scan spend justifies autoscaling slots
- LLM only on novelties; cache-hit rate is a tracked KPI

Order-of-magnitude at 1M devices: **~$350–1,100/month all-in.**

## SCD2 incremental design (read before editing fridge_items)

`item_events` is a plain incremental: events are append-only, so a "last N
days" filter is safe.

`fridge_items` is **not**, and this is the subtlest part of the pipeline.
`lead()` looks *forward*: the `item_removed` that closes an interval can
arrive days or weeks after the `item_added` that opened it. Applying the same
last-N-days filter would put the original addition out of scope, so the
interval would never close — silently, forever, with no test failing. Waste
and replenishment metrics would quietly rot.

The fix never re-reads old events. A removal is always *recent*, and the open
interval it closes is already stored in the table. So each run scopes to:

- **(a)** events in the last `scd2_lookback_days` (default 7) → new intervals
- **(b)** rows in `{{ this }}` where `is_current` → intervals a recent removal closes

then **MERGEs on `item_sk`**, which lets an existing row be *updated* (closed).
`insert_overwrite` cannot update an old partition's rows from new data, which
is why the strategy is `merge`.

Intervals open past `scd2_max_open_days` (default 180) are retired with
`closure_reason = 'timeout'` and `valid_to = NULL` — treated as a missed
removal rather than a fabricated timestamp, so waste metrics can exclude them.

Guarded by `tests/assert_no_stale_open_intervals.sql`, which turns this
otherwise-silent failure into a loud CI error. Runnable proof of both the bug
and the fix: `local/demo_scd2.py`.
