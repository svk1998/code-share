# Architecture

```
Family Hub fridge ──(L1–L4 diffs)──► SmartThings cloud ──(gzip JSONL, 4–6h)──►
GCS landing/ ──► Validator (Cloud Run Job, JSON-Schema contract)
   ├── valid    ──► raw/device_id=…/date=…/  ──► BigQuery LOAD JOB (free) ──► bronze.raw_events
   └── invalid  ──► quarantine/ + bronze.rejected_events (DLQ)

bronze ──► dbt (Cloud Run Job) ──► silver (item_events dedup, fridge_items SCD2, product_catalog)
                                     ▲
        enrichment (Cloud Run Job) ──┘  cache → BQ vector search → LLM batch, write-back
silver ──► dbt ──► gold (household_features, replenishment_cycles, health_scores, segments)

Orchestration : Cloud Scheduler → Cloud Workflows → Cloud Run Jobs (scale-to-zero)
Governance    : ops.deletion_requests → nightly erasure job; Terraform retention/lifecycle
Observability : 3 SLOs (freshness, completeness, quality) + Cloud Monitoring alerts
```

## Why batch, not streaming

Fridge events have no real-time requirement. BigQuery **load jobs are free**,
so the main path avoids Pub/Sub and Dataflow entirely. A narrow streaming
path can be added later *only* for a specific real-time feature.

## Cost levers

- Diffs, not snapshots (10–20× volume reduction at the device)
- Physical storage billing on all datasets (3–5× cheaper for compressed JSON)
- `require_partition_filter = true` blocks runaway ad-hoc scans
- Cloud Workflows + Scheduler instead of Composer (saves ~$400/mo idle)
- On-demand BigQuery until scan spend justifies autoscaling slots
- LLM only on novelties; cache-hit rate is a tracked KPI

Order-of-magnitude at 1M devices: **~$350–1,100/month all-in.**
