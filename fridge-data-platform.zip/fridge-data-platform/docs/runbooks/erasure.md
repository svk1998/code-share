# Runbook: Right-to-erasure (DPDP / GDPR)

## Submit a request
```sql
INSERT INTO `PROJECT.ops.deletion_requests`
  (request_id, device_id, requested_at, status)
VALUES (GENERATE_UUID(), 'FH-01234', CURRENT_TIMESTAMP(), 'pending');
```

## What the nightly job does
1. `DELETE` the device from bronze / silver / gold
2. Prefix-delete `raw/device_id=<id>/` in GCS
3. Write a SHA-256 tombstone to `ops.erasure_tombstones` (audit proof)
4. Mark the request `done`

## SLA
BigQuery physically purges within its 7-day time-travel window → the
30-day statutory window is comfortably met. Aggregated gold rows are
designed to survive individual erasure (already anonymized).

## Verify
```sql
SELECT status, completed_at FROM `PROJECT.ops.deletion_requests`
WHERE device_id = 'FH-01234';
SELECT COUNT(*) FROM `PROJECT.silver.item_events` WHERE device_id='FH-01234';  -- expect 0
```
