# Runbook: Backfill / reprocess a date range

Raw events are immutable in GCS (`raw/`), so any window can be rebuilt.

## Reprocess silver/gold for a partition range
```bash
cd dbt
# Rebuild only the affected days by overriding the incremental floor.
dbt run --select item_events fridge_items+ \
  --vars '{"backfill_start":"2026-07-01","backfill_end":"2026-07-07"}' \
  --target prod
```
> `insert_overwrite` replaces whole day partitions — safe to re-run.

## Re-load bronze from the GCS archive
If bronze partitions were lost/expired:
```bash
# Remove the loaded-file markers for the window, then re-run the loader job.
bq query --use_legacy_sql=false \
 'DELETE FROM `PROJECT.ops.loaded_files`
  WHERE source_file LIKE "raw/%date=2026-07-0%"'
gcloud run jobs execute fridge-loader --region asia-south1
```
event_id dedup in `item_events` makes double-loads harmless.

## Full refresh (deliberate only)
```bash
dbt build --full-refresh --target prod   # flagged operation, off-hours
```
