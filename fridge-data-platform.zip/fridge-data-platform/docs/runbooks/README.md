# Runbooks
- [backfill.md](backfill.md) — reprocess a date range / re-load bronze
- [erasure.md](erasure.md) — DPDP/GDPR right-to-erasure
