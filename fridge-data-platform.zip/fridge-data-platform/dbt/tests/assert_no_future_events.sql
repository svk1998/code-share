-- Data-quality guard: captured_at must not be in the future.
select event_id, captured_at
from {{ ref('item_events') }}
where captured_at > timestamp_add(current_timestamp(), interval 1 hour)
