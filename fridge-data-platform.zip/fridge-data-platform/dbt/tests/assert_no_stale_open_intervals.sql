-- CANARY for the SCD2 lookback bug (rows returned = FAIL).
--
-- If intervals stop being closed, they pile up as "still in the fridge"
-- forever and nothing else in the pipeline complains. This test is what
-- turns that silent rot into a loud CI failure.
select item_sk, device_id, l2_type, l3_brand, valid_from
from {{ ref('fridge_items') }}
where is_current
  and valid_from < timestamp_sub(current_timestamp(),
                                 interval {{ var('scd2_max_open_days', 180) }} day)
