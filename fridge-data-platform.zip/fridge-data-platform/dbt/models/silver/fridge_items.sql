{{ config(
    materialized='incremental',
    unique_key='item_sk',
    incremental_strategy='merge',
    partition_by={'field': 'valid_from', 'data_type': 'timestamp', 'granularity': 'day'},
    cluster_by=['device_id', 'is_current']
) }}

{% set lookback_days = var('scd2_lookback_days', 7) %}
{% set max_open_days = var('scd2_max_open_days', 180) %}

-- SCD Type 2 presence history per (device, product line).
-- item_added opens an interval, item_removed closes it -> the appear/disappear
-- history that powers replenishment + waste analytics downstream.
--
-- WHY THIS ISN'T A PLAIN INCREMENTAL (read before editing):
--   lead() looks FORWARD in time. The removal that closes an interval can
--   arrive days or weeks after the addition. Adding the "obvious" last-N-days
--   filter (as item_events uses) would put the original item_added out of
--   scope, so the interval would NEVER close -- silently, forever. Waste and
--   replenishment metrics would rot with no test failing.
--   See local/demo_scd2.py for a runnable proof.
--
-- THE INSIGHT: we never need to re-read old events. A removal is always
-- RECENT, and the open interval it closes is already stored in this table.
-- Each run therefore scopes to:
--   (a) recent events           -> brand-new intervals
--   (b) open rows in {{ this }} -> intervals a recent removal closes
-- ...then MERGEs on item_sk, which lets an existing row be UPDATED (closed).
-- insert_overwrite cannot do that, which is why the strategy is merge.

with recent as (
    select device_id, l1_category, l2_type, l3_brand, event_type, captured_at
    from {{ ref('item_events') }}
    where event_type in ('item_added', 'item_removed')
    {% if is_incremental() %}
      and captured_at >= timestamp_sub(current_timestamp(), interval {{ lookback_days }} day)
    {% endif %}
),

-- (a) intervals opened by adds inside the recent window
paired as (
    select device_id, l1_category, l2_type, l3_brand,
           captured_at as valid_from,
           event_type,
           lead(captured_at) over w as next_ts,
           lead(event_type)  over w as next_event
    from recent
    window w as (
        partition by device_id, l1_category, l2_type, l3_brand
        order by captured_at
    )
),
new_intervals as (
    select device_id, l1_category, l2_type, l3_brand, valid_from,
           case when next_event = 'item_removed' then next_ts end as valid_to,
           (next_event is null or next_event != 'item_removed') as is_current,
           case when next_event = 'item_removed' then 'removed' else 'open' end as closure_reason
    from paired
    where event_type = 'item_added'
)

{% if is_incremental() %}
-- (b) close intervals left open by an EARLIER run
, open_prev as (
    select device_id, l1_category, l2_type, l3_brand, valid_from
    from {{ this }}
    where is_current
      and valid_from >= timestamp_sub(current_timestamp(), interval {{ max_open_days }} day)
),
closures as (
    select p.device_id, p.l1_category, p.l2_type, p.l3_brand, p.valid_from,
           min(r.captured_at) as valid_to,
           false as is_current,
           'removed' as closure_reason
    from open_prev p
    join recent r
      on  r.device_id   = p.device_id
      and r.l1_category = p.l1_category
      and r.l2_type     = p.l2_type
      and coalesce(r.l3_brand, '__NULL__') = coalesce(p.l3_brand, '__NULL__')
      and r.event_type  = 'item_removed'
      and r.captured_at > p.valid_from
    group by 1, 2, 3, 4, 5
),
-- An interval open past max_open_days is a MISSED removal, not a 6-month-old
-- yogurt. Retire it, but leave valid_to NULL so waste metrics can exclude it
-- rather than trusting a fabricated timestamp.
stale as (
    select device_id, l1_category, l2_type, l3_brand, valid_from,
           cast(null as timestamp) as valid_to,
           false as is_current,
           'timeout' as closure_reason
    from {{ this }}
    where is_current
      and valid_from < timestamp_sub(current_timestamp(), interval {{ max_open_days }} day)
)
{% endif %}

, unioned as (
    select * from new_intervals
    {% if is_incremental() %}
    union all select * from closures
    union all select * from stale
    {% endif %}
),
-- The same interval can surface in both new_intervals and closures. A MERGE
-- must match at most one source row per target row, so dedupe and prefer the
-- CLOSED version.
deduped as (
    select *, row_number() over (
        partition by device_id, l2_type, coalesce(l3_brand, ''), valid_from
        order by is_current asc, valid_to asc
    ) as rn
    from unioned
)
select
    {{ dbt_utils.generate_surrogate_key(['device_id','l2_type','l3_brand','valid_from']) }} as item_sk,
    device_id, l1_category, l2_type, l3_brand,
    valid_from, valid_to, is_current, closure_reason
from deduped
where rn = 1
