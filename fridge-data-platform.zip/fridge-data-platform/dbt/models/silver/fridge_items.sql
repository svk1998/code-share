{{ config(
    materialized='incremental',
    partition_by={'field': 'valid_from', 'data_type': 'timestamp', 'granularity': 'day'},
    cluster_by=['device_id', 'is_current'],
    incremental_strategy='insert_overwrite'
) }}

-- SCD Type 2 presence history per (device, product line).
-- item_added opens an interval, item_removed closes it -> appear/disappear
-- history that powers replenishment + waste analytics downstream.
with events as (
    select
        device_id,
        l1_category,
        l2_type,
        l3_brand,
        event_type,
        captured_at
    from {{ ref('item_events') }}
    where event_type in ('item_added', 'item_removed')
),
paired as (
    select
        device_id, l1_category, l2_type, l3_brand,
        captured_at as valid_from,
        lead(captured_at) over (
            partition by device_id, l1_category, l2_type, l3_brand
            order by captured_at
        ) as next_ts,
        event_type,
        lead(event_type) over (
            partition by device_id, l1_category, l2_type, l3_brand
            order by captured_at
        ) as next_event
    from events
)
select
    {{ dbt_utils.generate_surrogate_key(['device_id','l2_type','l3_brand','valid_from']) }} as item_sk,
    device_id, l1_category, l2_type, l3_brand,
    valid_from,
    case when next_event = 'item_removed' then next_ts else null end as valid_to,
    (next_event is null or next_event != 'item_removed') as is_current
from paired
where event_type = 'item_added'
