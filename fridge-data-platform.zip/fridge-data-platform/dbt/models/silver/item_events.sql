{{ config(
    materialized='incremental',
    partition_by={'field': 'captured_at', 'data_type': 'timestamp', 'granularity': 'day'},
    cluster_by=['device_id'],
    incremental_strategy='insert_overwrite',
    unique_key='event_id'
) }}

-- Deduped, typed events. insert_overwrite by day => history never rebuilt.
with src as (
    select
        event_id,
        device_id,
        event_type,
        captured_at,
        json_value(payload, '$.l1_category') as l1_category,
        json_value(payload, '$.l2_type')     as l2_type,
        json_value(payload, '$.l3_brand')    as l3_brand,
        json_query(payload, '$.l4_text')     as l4_text,
        safe_cast(json_value(payload, '$.confidence') as float64) as confidence,
        safe_cast(json_value(payload, '$.fill_level') as float64) as fill_level,
        ingested_at
    from {{ source('bronze', 'raw_events') }}
    -- bronze.raw_events sets require_partition_filter = true, so EVERY query
    -- must predicate on captured_at -- including the very first, non-incremental
    -- build. Without this floor the initial `dbt run` is rejected by BigQuery.
    -- Bronze partitions expire at 90d, so a 400d floor reads all data that exists.
    where captured_at >= timestamp_sub(
        current_timestamp(), interval {{ var('bronze_max_history_days', 400) }} day)
    {% if is_incremental() %}
      and captured_at >= timestamp_sub(
        (select max(captured_at) from {{ this }}), interval 2 day)
    {% endif %}
),
deduped as (
    select *, row_number() over (
        partition by event_id order by ingested_at desc
    ) as rn
    from src
)
select * except (rn) from deduped where rn = 1
