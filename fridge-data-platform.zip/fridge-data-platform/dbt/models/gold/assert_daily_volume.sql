{{ config(materialized='view') }}

-- SLO 2 (completeness): daily volume within +/-30% of trailing 7-day median.
-- Rows returned = breaches. Wire a dbt test / scheduled query alert on count>0.
with daily as (
    select date(captured_at) as d, count(*) as n
    from {{ ref('item_events') }}
    where captured_at >= timestamp_sub(current_timestamp(), interval 14 day)
    group by d
),
med as (
    select d, n,
        approx_quantiles(n, 100) over (
            order by d rows between 7 preceding and 1 preceding
        )[offset(50)] as median_7d
    from daily
)
select d, n, median_7d
from med
where median_7d is not null
  and (n < 0.7 * median_7d or n > 1.3 * median_7d)
