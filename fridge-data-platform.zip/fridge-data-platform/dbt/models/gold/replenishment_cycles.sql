{{ config(materialized='table') }}

-- Median gap between successive appearances of the same product line per
-- household = purchase/consumption frequency. Only retailers' post-purchase
-- blind spot; this is derivable here.
with appearances as (
    select
        device_id, l2_type, l3_brand, valid_from,
        lag(valid_from) over (
            partition by device_id, l2_type, l3_brand order by valid_from
        ) as prev_from
    from {{ ref('fridge_items') }}
)
select
    device_id, l2_type, l3_brand,
    count(*) as cycles,
    approx_quantiles(timestamp_diff(valid_from, prev_from, hour), 100)[offset(50)] as median_gap_hours
from appearances
where prev_from is not null
group by device_id, l2_type, l3_brand
having cycles >= 2
