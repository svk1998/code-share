{{ config(
    materialized='incremental',
    partition_by={'field': 'as_of_date', 'data_type': 'date', 'granularity': 'day'},
    cluster_by=['device_id'],
    incremental_strategy='insert_overwrite'
) }}

-- One row per device per day: the household feature vector that segments,
-- health scores and ad audiences are built from. Fridge = household node.
with window_events as (
    select *
    from {{ ref('item_events') }}
    where captured_at >= timestamp_sub(current_timestamp(), interval 30 day)
),
per_device as (
    select
        device_id,
        current_date() as as_of_date,
        count(*) as events_30d,
        count(distinct l2_type) as distinct_types_30d,
        countif(l1_category = 'Beverages') as beverage_events,
        countif(l1_category = 'Produce')   as produce_events,
        countif(l1_category = 'Leftovers') as leftover_events,
        countif(l1_category = 'Frozen')    as frozen_events,
        safe_divide(countif(l1_category = 'Leftovers'), count(*)) as home_cooking_ratio
    from window_events
    group by device_id
)
select * from per_device
