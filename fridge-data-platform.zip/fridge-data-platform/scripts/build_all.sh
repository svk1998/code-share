#!/usr/bin/env bash
# Build & push all service images to Artifact Registry.
set -euo pipefail
: "${PROJECT:?set PROJECT}" "${REGION:=asia-south1}"
REPO="${REGION}-docker.pkg.dev/${PROJECT}/pipeline"
for svc in validator loader enrichment erasure; do
  echo ">> building $svc"
  gcloud builds submit "services/$svc" --tag "$REPO/$svc:latest"
done
# dbt image (uses the community dbt-bigquery base + our project)
echo ">> building dbt-build"
gcloud builds submit dbt --tag "$REPO/dbt-build:latest" || \
  echo "add dbt/Dockerfile to build the dbt runner image"
