#!/usr/bin/env python3
"""Generate synthetic fridge diff events (gzip JSONL) for end-to-end testing.

Emits realistic add/remove/level_changed events across a set of households,
optionally uploading directly to the landing/ prefix so the whole pipeline
(validator -> loader -> dbt) can be exercised on real infra.

  python scripts/generate_synthetic_events.py --devices 200 --days 7 \
      --bucket my-bucket --upload
"""
import argparse
import gzip
import io
import json
import random
import hashlib
import datetime as dt

CATALOG = {
    "Beverages": {
        "Soda": ["Coca-Cola", "Pepsi", "Thums Up"],
        "Juice": ["Real", "Tropicana", "Frooti"],
        "Milk": ["Amul", "Mother Dairy", "Nestle"],
    },
    "Dairy": {
        "Butter": ["Amul", "Britannia"],
        "Cheese": ["Amul", "Go"],
        "Yogurt": ["Epigamia", "Amul"],
    },
    "Condiments": {"Mayonnaise": ["Veeba", "Fun Foods"], "Ketchup": ["Kissan", "Maggi"]},
    "Produce": {"Spinach": [None], "Tomato": [None], "Apple": [None]},
    "Leftovers": {"Curry": [None], "Rice": [None]},
    "Frozen": {"Peas": ["Safal"], "Nuggets": ["McCain"]},
}
EVENT_TYPES = ["item_added", "item_removed", "level_changed"]


def event_id(device_id, ts, item):
    return hashlib.sha256(
        f"{device_id}|{ts}|{json.dumps(item, sort_keys=True)}".encode()
    ).hexdigest()[:32]


def gen_event(device_id, ts):
    l1 = random.choice(list(CATALOG))
    l2 = random.choice(list(CATALOG[l1]))
    l3 = random.choice(CATALOG[l1][l2])
    etype = random.choices(EVENT_TYPES, weights=[0.45, 0.35, 0.20])[0]
    payload = {
        "l1_category": l1,
        "l2_type": l2,
        "l3_brand": l3,
        "l4_text": {"name": f"{l3 or l2} {random.choice(['500g','1L','200ml','250g'])}",
                    "calories": random.choice([None, 90, 150, 240])},
        "confidence": round(random.uniform(0.72, 0.99), 3),
        "fill_level": round(random.uniform(0, 1), 2) if etype == "level_changed" else None,
    }
    iso = ts.replace(microsecond=0).isoformat()
    return {
        "event_id": event_id(device_id, iso, payload),
        "device_id": device_id,
        "schema_version": "v1",
        "event_type": etype,
        "captured_at": iso,
        "payload": payload,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--devices", type=int, default=50)
    ap.add_argument("--days", type=int, default=7)
    ap.add_argument("--bucket", default=None)
    ap.add_argument("--upload", action="store_true")
    ap.add_argument("--out", default="synthetic_events")
    args = ap.parse_args()

    start = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=args.days)
    files = {}  # (device, day) -> list[str]

    for d in range(args.devices):
        device_id = f"FH-{d:05d}"
        for day in range(args.days):
            base = start + dt.timedelta(days=day)
            for _ in range(random.randint(6, 14)):  # a few captures worth of diffs
                ts = base + dt.timedelta(seconds=random.randint(0, 86399))
                evt = gen_event(device_id, ts)
                files.setdefault((device_id, base.date().isoformat()), []).append(json.dumps(evt))

    if args.upload:
        from google.cloud import storage
        gcs = storage.Client()
        bucket = gcs.bucket(args.bucket)
        for (device_id, day), lines in files.items():
            buf = io.BytesIO()
            with gzip.GzipFile(fileobj=buf, mode="wb") as gz:
                gz.write("\n".join(lines).encode())
            key = f"landing/{device_id}_{day}.jsonl.gz"
            bucket.blob(key).upload_from_string(buf.getvalue(), content_type="application/gzip")
        print(f"uploaded {len(files)} gzip batches to gs://{args.bucket}/landing/")
    else:
        import os
        os.makedirs(args.out, exist_ok=True)
        for (device_id, day), lines in files.items():
            with gzip.open(f"{args.out}/{device_id}_{day}.jsonl.gz", "wb") as f:
                f.write("\n".join(lines).encode())
        total = sum(len(v) for v in files.values())
        print(f"wrote {len(files)} batches ({total} events) to ./{args.out}/")


if __name__ == "__main__":
    main()
