#!/usr/bin/env bash
# One command: fake fridges -> validator -> loader -> dbt -> results.
# No GCP. No credentials. No cost.
set -euo pipefail
cd "$(dirname "$0")"

echo "--- 0. clean slate ---"
rm -rf data fridge.duckdb dbt_local/target
mkdir -p data/landing

echo "--- 1. generate synthetic fridge events ---"
python ../scripts/generate_synthetic_events.py --devices 8 --days 14 --out data/landing

echo "--- 2. validator: contract check, landing/ -> raw/ or quarantine/ ---"
python local_validator.py

echo "--- 3. loader: raw/*.ndjson -> bronze.raw_events (DuckDB) ---"
python local_loader.py

echo "--- 4. dbt: bronze -> silver -> gold, with tests ---"
cd dbt_local && DBT_PROFILES_DIR=. dbt build --target local 2>&1 | grep -Ev '^$' | tail -25
cd ..

echo ""
echo "--- 5. what got built ---"
python peek.py
