# Local sandbox — learn the pipeline with no GCP, no cost

Everything except the GCP plumbing runs on your laptop. DuckDB stands in for
BigQuery; the local filesystem stands in for GCS.

```bash
pip install dbt-duckdb jsonschema
./run_local.sh
```

That's it. ~10 seconds, no credentials, no bill.

## What maps to what

| Production (GCP) | Sandbox (laptop) |
|---|---|
| GCS bucket | `local/data/` folders |
| `bronze.raw_events` in BigQuery | `bronze.raw_events` in `fridge.duckdb` |
| Validator Cloud Run Job | `local_validator.py` |
| Loader Cloud Run Job (BQ load job) | `local_loader.py` |
| dbt on BigQuery | dbt on DuckDB (`dbt_local/`) |
| Cloud Workflows | `run_local.sh` |

The validator reads **the same contract file** as production
(`services/validator/contracts/`) — so the contract can't drift.

## The 5 steps run_local.sh performs

1. **generate** — fake fridges emit add/remove/level diffs
2. **validate** — contract check → `data/raw/` or `data/quarantine/`
3. **load** — ndjson → `bronze.raw_events`
4. **dbt build** — bronze → silver → gold, running tests as it goes
5. **peek** — prints the tables, including the SCD2 timeline

## Exercises (do these — this is the actual learning)

**0. See a real bug and its fix.**
```bash
python demo_scd2.py
```
One fridge, one bottle of ketchup: added 20 days ago, removed today. It builds
two models side by side — `fridge_items_naive` (with the "obvious" last-2-days
incremental filter) and `fridge_items` (the real one). The naive model leaves
the ketchup **in the fridge forever**; the fixed one closes the interval.
This is the single most important idea in the pipeline, so run it first.


**1. See the timeline get built.**
```bash
python peek.py
```
Look at `fridge_items`: each row is `appeared → gone`. That's the whole
point of the pipeline — dots become intervals.

**2. Prove re-running is safe (idempotency).**
```bash
python local_loader.py && cd dbt_local && DBT_PROFILES_DIR=. dbt build --target local
```
Row counts don't change. The `event_id` hash is why. This is the property
that lets you fix things at 2am by just re-running.

**3. Break the contract on purpose.**
Edit a generated event to `"schema_version": "v2"` and re-run the validator.
It goes to `data/quarantine/` with a reason — not silently dropped. That's
what "DLQ" means in practice.

**4. Make a test fail.**
In `dbt_local/models/silver/_silver.yml`, add `Chocolate` to nothing and
instead remove `'Frozen'` from the `accepted_values` list. Re-run
`dbt build`. Watch the test fail and downstream models get skipped —
that's the gate that keeps bad data out of gold.

**5. Watch incremental do less work.**
```bash
cd dbt_local && DBT_PROFILES_DIR=. dbt build --target local   # 2nd run
```
`item_events` is incremental: the `{% if is_incremental() %}` block now
applies, so it only re-reads the last 2 days instead of everything.

**6. See the lineage graph.**
```bash
cd dbt_local && DBT_PROFILES_DIR=. dbt docs generate && DBT_PROFILES_DIR=. dbt docs serve
```
Browser opens with the DAG that `ref()` built automatically.

## Poke at the data yourself
```bash
python -c "import duckdb; duckdb.connect('fridge.duckdb').sql('''
  select l2_type, count(*) c from silver.item_events group by 1 order by c desc
''').show()"
```

## SQL dialect differences (BigQuery → DuckDB)

The models are ported, not identical. What changed:

| BigQuery | DuckDB |
|---|---|
| `json_value(payload,'$.x')` | `json_extract_string(payload,'$.x')` |
| `safe_cast(x as float64)` | `try_cast(x as double)` |
| `timestamp_sub(t, interval 2 day)` | `t - interval 2 day` |
| `countif(cond)` | `count(*) filter (where cond)` |
| `approx_quantiles(x,100)[offset(50)]` | `median(x)` |
| `partition_by` / `cluster_by` config | (dropped — BQ-specific cost features) |
| `where captured_at >= ...` floor in `item_events` | (dropped — only needed because BQ sets `require_partition_filter`) |
| `incremental_strategy='merge'` | `delete+insert` (same semantics here) |

**Caveat:** because of this, `local/dbt_local/models/` is a *learning mirror*
of `dbt/models/`, not the same code. If you change a real model, port the
change by hand. The logic is 1:1; only the dialect differs.
