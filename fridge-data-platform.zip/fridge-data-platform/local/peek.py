#!/usr/bin/env python3
"""Show what the pipeline built — the whole point is to SEE the SCD2 timeline."""
import duckdb, sys
from pathlib import Path

con = duckdb.connect(str(Path(__file__).parent / "fridge.duckdb"))

def show(title, sql):
    print(f"\n{'='*70}\n{title}\n{'='*70}")
    try:
        print(con.sql(sql))
    except Exception as e:
        print(f"  (not built yet: {e})")

show("BRONZE — raw events as they landed",
     "select event_id[1:8] as event_id, device_id, event_type, captured_at from bronze.raw_events limit 5")

show("SILVER item_events — JSON unpacked into columns",
     "select device_id, event_type, l1_category, l2_type, l3_brand, captured_at "
     "from silver.item_events order by device_id, captured_at limit 8")

show("SILVER fridge_items — THE TIMELINE (SCD2)",
     """select device_id, l2_type, l3_brand,
               strftime(valid_from, '%m-%d %H:%M') as appeared,
               coalesce(strftime(valid_to, '%m-%d %H:%M'), '-- still there --') as gone,
               is_current
        from silver.fridge_items order by device_id, valid_from limit 10""")

show("GOLD household_features — one row per fridge",
     "select * from gold.household_features order by events_30d desc limit 5")

show("GOLD replenishment_cycles — how often they re-stock",
     "select device_id, l2_type, l3_brand, cycles, median_gap_hours "
     "from gold.replenishment_cycles order by cycles desc limit 8")

# The teaching moment: one product's full life story in one fridge
try:
    dev = con.sql("select device_id from silver.fridge_items limit 1").fetchone()
except Exception:
    dev = None
if dev:
    show(f"ONE PRODUCT LINE'S LIFE STORY in fridge {dev[0]}",
         f"""select l2_type, l3_brand,
                    strftime(valid_from,'%m-%d %H:%M') as appeared,
                    coalesce(strftime(valid_to,'%m-%d %H:%M'),'still there') as gone,
                    case when valid_to is not null
                         then date_diff('hour', valid_from, valid_to) || ' h in fridge'
                         else '' end as lifespan
             from silver.fridge_items
             where device_id = '{dev[0]}'
             order by l2_type, valid_from limit 12""")
print()
