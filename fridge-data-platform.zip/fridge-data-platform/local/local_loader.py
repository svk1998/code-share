#!/usr/bin/env python3
"""LOCAL mirror of services/loader/main.py — loads raw/*.ndjson into DuckDB.

Same idea as the BigQuery load job: read the ndjson files, append into
bronze_raw_events, and track what's been loaded so a re-run never double-loads.
"""
import duckdb
from pathlib import Path

HERE = Path(__file__).parent
DB = HERE / "fridge.duckdb"
RAW = HERE / "data" / "raw"


def main():
    con = duckdb.connect(str(DB))
    con.execute("CREATE SCHEMA IF NOT EXISTS bronze")
    con.execute("CREATE SCHEMA IF NOT EXISTS ops")
    con.execute("""
        CREATE TABLE IF NOT EXISTS bronze.raw_events (
            event_id VARCHAR, device_id VARCHAR, schema_version VARCHAR,
            event_type VARCHAR, captured_at TIMESTAMP, payload VARCHAR,
            ingested_at TIMESTAMP, source_file VARCHAR
        )""")
    con.execute("CREATE TABLE IF NOT EXISTS ops.loaded_files (source_file VARCHAR, loaded_at TIMESTAMP)")

    loaded = {r[0] for r in con.execute("SELECT source_file FROM ops.loaded_files").fetchall()}
    files = [str(p) for p in RAW.rglob("*.ndjson") if str(p) not in loaded]
    if not files:
        print("loader: nothing new to load")
        return

    con.execute(f"""
        INSERT INTO bronze.raw_events
        SELECT event_id, device_id, schema_version, event_type,
               CAST(captured_at AS TIMESTAMP), payload,
               CAST(ingested_at AS TIMESTAMP), source_file
        FROM read_json_auto({files}, format='newline_delimited')
    """)
    con.executemany("INSERT INTO ops.loaded_files VALUES (?, now())", [(f,) for f in files])
    n = con.execute("SELECT count(*) FROM bronze.raw_events").fetchone()[0]
    print(f"loader: loaded {len(files)} files -> bronze.raw_events now has {n} rows")


if __name__ == "__main__":
    main()
