#!/usr/bin/env python3
"""LOCAL mirror of services/validator/main.py — same logic, no GCS.

Reads gzip JSONL from local/data/landing/, validates each line against the
same contract file the real validator uses, and writes:
  valid   -> local/data/raw/device_id=X/date=Y/*.ndjson
  invalid -> local/data/quarantine/  + prints the rejection reason
"""
import gzip, json, hashlib, datetime as dt, shutil
from pathlib import Path
from jsonschema import Draft202012Validator

HERE = Path(__file__).parent
DATA = HERE / "data"
CONTRACTS = HERE.parent / "services" / "validator" / "contracts"   # same contracts as prod

_SCHEMAS = {
    p.name.split(".")[0].replace("event_", ""): Draft202012Validator(json.loads(p.read_text()))
    for p in CONTRACTS.glob("event_*.schema.json")
}


def _event_id(device_id, captured_at, item):
    return hashlib.sha256(
        f"{device_id}|{captured_at}|{json.dumps(item, sort_keys=True)}".encode()
    ).hexdigest()[:32]


def main():
    landing = DATA / "landing"
    raw, quarantine = DATA / "raw", DATA / "quarantine"
    raw.mkdir(parents=True, exist_ok=True)
    quarantine.mkdir(parents=True, exist_ok=True)

    now = dt.datetime.now(dt.timezone.utc).isoformat()
    total_good = total_bad = 0

    for f in sorted(landing.glob("*.jsonl.gz")):
        good, bad = [], []
        for i, line in enumerate(gzip.open(f, "rt").read().splitlines()):
            if not line.strip():
                continue
            try:
                evt = json.loads(line)
            except json.JSONDecodeError as e:
                bad.append((i, f"invalid json: {e}"))
                continue

            validator = _SCHEMAS.get(evt.get("schema_version"))
            if validator is None:
                bad.append((i, f"unknown schema_version: {evt.get('schema_version')}"))
                continue
            errs = sorted(validator.iter_errors(evt), key=lambda e: str(e.path))
            if errs:
                bad.append((i, errs[0].message))
                continue

            evt.setdefault("event_id", _event_id(evt["device_id"], evt["captured_at"], evt["payload"]))
            evt["ingested_at"] = now
            evt["source_file"] = f.name
            evt["payload"] = json.dumps(evt["payload"])   # JSON column as string
            good.append(evt)

        # write valid events into the per-device / per-day prefix layout
        by_key = {}
        for e in good:
            key = raw / f"device_id={e['device_id']}" / f"date={e['captured_at'][:10]}"
            by_key.setdefault(key, []).append(json.dumps(e))
        for key, lines in by_key.items():
            key.mkdir(parents=True, exist_ok=True)
            (key / f"{f.stem}.ndjson").write_text("\n".join(lines))

        if bad:
            shutil.copy(f, quarantine / f.name)
            for ln, reason in bad[:3]:
                print(f"  QUARANTINE {f.name} line {ln}: {reason}")

        f.unlink()   # landing file consumed — re-running is a no-op
        total_good += len(good)
        total_bad += len(bad)

    print(f"validator: {total_good} valid, {total_bad} rejected")


if __name__ == "__main__":
    main()
