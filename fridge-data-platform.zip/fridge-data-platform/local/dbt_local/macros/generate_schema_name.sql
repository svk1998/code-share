{# By default dbt PREFIXES custom schemas with the target schema, giving
   "main_silver". This standard override uses the custom schema verbatim,
   so the sandbox uses the same names as BigQuery: silver / gold. #}
{% macro generate_schema_name(custom_schema_name, node) -%}
    {%- if custom_schema_name is none -%}
        {{ target.schema }}
    {%- else -%}
        {{ custom_schema_name | trim }}
    {%- endif -%}
{%- endmacro %}
