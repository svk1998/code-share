{{ config(materialized='table') }}

-- How often does this household re-stock this product line?
-- lag() = look BACK at the previous appearance; the gap between them is
-- the repurchase cycle. BigQuery approx_quantiles(...)[offset(50)] -> median()
with appearances as (
    select
        device_id, l2_type, l3_brand, valid_from,
        lag(valid_from) over (
            partition by device_id, l2_type, l3_brand order by valid_from
        ) as prev_from
    from {{ ref('fridge_items') }}
)
select
    device_id, l2_type, l3_brand,
    count(*)                                                  as cycles,
    round(median(date_diff('hour', prev_from, valid_from)), 1) as median_gap_hours
from appearances
where prev_from is not null
group by device_id, l2_type, l3_brand
having count(*) >= 2
