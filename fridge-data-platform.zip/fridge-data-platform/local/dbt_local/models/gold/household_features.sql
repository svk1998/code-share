{{ config(materialized='table') }}

-- One row per household: the feature vector segments are built from.
-- BigQuery countif(x) -> DuckDB count(*) filter (where x)
select
    device_id,
    current_date as as_of_date,
    count(*)                                            as events_30d,
    count(distinct l2_type)                             as distinct_types_30d,
    count(*) filter (where l1_category = 'Beverages')   as beverage_events,
    count(*) filter (where l1_category = 'Produce')     as produce_events,
    count(*) filter (where l1_category = 'Leftovers')   as leftover_events,
    round(count(*) filter (where l1_category = 'Leftovers')
          / nullif(count(*), 0), 3)                     as home_cooking_ratio
from {{ ref('item_events') }}
group by device_id
