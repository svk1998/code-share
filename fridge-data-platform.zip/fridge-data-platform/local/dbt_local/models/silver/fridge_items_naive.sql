{{ config(materialized='incremental', unique_key='item_sk',
          incremental_strategy='delete+insert', tags=['demo']) }}

-- DEMO ONLY -- this is the TRAP. It looks identical to the item_events
-- pattern, but lead() looks FORWARD in time: the removal that closes an
-- interval can arrive weeks after the addition. With a "last 2 days" filter
-- the original item_added is out of scope, so the interval is never closed.
with scope as (
    select device_id, l1_category, l2_type, l3_brand, event_type, captured_at
    from {{ ref('item_events') }}
    where event_type in ('item_added', 'item_removed')
    {% if is_incremental() %}
      and captured_at >= current_timestamp - interval 2 day
    {% endif %}
),
paired as (
    select device_id, l1_category, l2_type, l3_brand,
           captured_at as valid_from, event_type,
           lead(captured_at) over w as next_ts,
           lead(event_type)  over w as next_event
    from scope
    window w as (partition by device_id, l1_category, l2_type, l3_brand order by captured_at)
)
select
    md5(concat_ws('|', device_id, l2_type, coalesce(l3_brand,''), cast(valid_from as varchar))) as item_sk,
    device_id, l1_category, l2_type, l3_brand, valid_from,
    case when next_event = 'item_removed' then next_ts end as valid_to,
    (next_event is null or next_event != 'item_removed') as is_current
from paired
where event_type = 'item_added'
