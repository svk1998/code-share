{{ config(materialized='incremental', unique_key='event_id') }}

-- Unpack the JSON blob into typed columns, then drop duplicates.
-- BigQuery: json_value()      -> DuckDB: json_extract_string()
-- BigQuery: safe_cast()       -> DuckDB: try_cast()
with src as (
    select
        event_id,
        device_id,
        event_type,
        captured_at,
        json_extract_string(payload, '$.l1_category') as l1_category,
        json_extract_string(payload, '$.l2_type')     as l2_type,
        json_extract_string(payload, '$.l3_brand')    as l3_brand,
        try_cast(json_extract_string(payload, '$.confidence') as double) as confidence,
        try_cast(json_extract_string(payload, '$.fill_level') as double) as fill_level,
        ingested_at
    from {{ source('bronze', 'raw_events') }}
    {% if is_incremental() %}
      -- only re-read recent data; this is the cost lever in BigQuery
      where captured_at >= (select max(captured_at) from {{ this }}) - interval 2 day
    {% endif %}
),
deduped as (
    select *, row_number() over (partition by event_id order by ingested_at desc) as rn
    from src
)
select * exclude (rn) from deduped where rn = 1
