-- CANARY for the SCD2 lookback bug (rows returned = FAIL).
-- An interval still "open" past max_open_days means removals stopped closing
-- intervals. Without this test that failure is completely silent.
select item_sk, device_id, l2_type, l3_brand, valid_from
from {{ ref('fridge_items') }}
where is_current
  and valid_from < current_timestamp - interval {{ var('scd2_max_open_days', 180) }} day
