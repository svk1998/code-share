-- Convention: rows returned = test FAILED.
select event_id, captured_at
from {{ ref('item_events') }}
where captured_at > current_timestamp + interval 1 hour
