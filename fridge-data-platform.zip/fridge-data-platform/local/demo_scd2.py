#!/usr/bin/env python3
"""Prove the SCD2 lookback bug, and prove the fix.

Scenario: ONE fridge, ONE bottle of ketchup.
  Day -20 : ketchup added      (batch 1)
  Day  -0 : ketchup removed    (batch 2, arrives 20 days later)

A naive "only read the last 2 days" incremental never sees the Day -20
addition, so it can never close the interval -> the ketchup looks like it's
still in the fridge FOREVER, and waste/replenishment metrics rot silently.
"""
import gzip, json, shutil, subprocess, datetime as dt, hashlib
from pathlib import Path
import duckdb

HERE = Path(__file__).parent
NOW = dt.datetime.now(dt.timezone.utc)


def batch(name, events):
    (HERE / "data" / "landing").mkdir(parents=True, exist_ok=True)
    with gzip.open(HERE / "data" / "landing" / f"{name}.jsonl.gz", "wb") as f:
        f.write("\n".join(json.dumps(e) for e in events).encode())


def evt(when, etype):
    payload = {"l1_category": "Condiments", "l2_type": "Ketchup",
               "l3_brand": "Kissan", "l4_text": {"name": "Kissan 500g"}, "confidence": 0.95}
    iso = when.replace(microsecond=0).isoformat()
    return {"event_id": hashlib.sha256(f"FH-TEST|{iso}|{etype}".encode()).hexdigest()[:32],
            "device_id": "FH-TEST", "schema_version": "v1", "event_type": etype,
            "captured_at": iso, "payload": payload}


def run(step):
    subprocess.run(["python", str(HERE / f"local_{step}.py")], check=True,
                   capture_output=True)


def dbt():
    subprocess.run(["dbt", "build", "--target", "local", "--select", "+fridge_items", "+fridge_items_naive"],
                   cwd=HERE / "dbt_local", env={**__import__("os").environ, "DBT_PROFILES_DIR": "."},
                   check=True, capture_output=True)


def report(stage):
    con = duckdb.connect(str(HERE / "fridge.duckdb"))
    print(f"\n  {stage}")
    for model in ("fridge_items_naive", "fridge_items"):
        try:
            r = con.sql(f"select valid_from, valid_to, is_current from silver.{model} "
                        f"where device_id='FH-TEST'").fetchall()
        except Exception as e:
            print(f"    {model:22} (missing: {e})"); continue
        if not r:
            print(f"    {model:22} no rows"); continue
        vf, vt, cur = r[0]
        state = "STILL IN FRIDGE" if cur else f"closed after {(vt-vf).days}d"
        print(f"    {model:22} valid_to={str(vt):>19}  ->  {state}")
    con.close()


print(__doc__)
shutil.rmtree(HERE / "data", ignore_errors=True)
(HERE / "fridge.duckdb").unlink(missing_ok=True)
shutil.rmtree(HERE / "dbt_local" / "target", ignore_errors=True)

print("=" * 74)
print("BATCH 1 — ketchup added 20 days ago")
print("=" * 74)
batch("b1", [evt(NOW - dt.timedelta(days=20), "item_added")])
run("validator"); run("loader"); dbt()
report("after batch 1 (both correct — the ketchup really IS in the fridge):")

print()
print("=" * 74)
print("BATCH 2 — ketchup removed today (20 days after it was added)")
print("=" * 74)
batch("b2", [evt(NOW - dt.timedelta(hours=1), "item_removed")])
run("validator"); run("loader"); dbt()
report("after batch 2 — THIS is where they diverge:")

print("""
  naive  : the 2-day window never saw the Day-20 'item_added', so there was
           nothing to attach the removal to. Interval stays open forever.
           -> waste metrics silently wrong, replenishment cycle never counted.

  fixed  : never re-reads old events. It joins the recent removal against the
           OPEN interval already stored in the table, and closes it.
""")
