output "data_bucket" {
  value = module.storage.data_bucket
}

output "pipeline_sa_email" {
  value = module.run_jobs.pipeline_sa_email
}
