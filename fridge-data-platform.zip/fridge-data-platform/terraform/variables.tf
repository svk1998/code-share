variable "project_id" {
  type        = string
  description = "GCP project for this environment (dev/stage/prod are separate projects)"
}

variable "region" {
  type    = string
  default = "asia-south1"
}

variable "env" {
  type        = string
  description = "dev | stage | prod"
}

variable "bronze_partition_expiration_days" {
  type    = number
  default = 90
}

variable "raw_archive_delete_after_days" {
  type    = number
  default = 1825 # 5 years; raw archive is the long-term replay copy
}

variable "alert_notification_channels" {
  type        = list(string)
  default     = []
  description = "Cloud Monitoring notification channel IDs"
}

variable "image_repo" {
  type        = string
  description = "Artifact Registry repo path, e.g. asia-south1-docker.pkg.dev/PROJECT/pipeline"
}
