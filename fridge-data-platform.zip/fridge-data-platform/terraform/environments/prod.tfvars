project_id = "samsung-fridge-prod"   # CHANGE ME
env        = "prod"
region     = "asia-south1"
image_repo = "asia-south1-docker.pkg.dev/samsung-fridge-prod/pipeline"
# alert_notification_channels = ["projects/samsung-fridge-prod/notificationChannels/123"]
