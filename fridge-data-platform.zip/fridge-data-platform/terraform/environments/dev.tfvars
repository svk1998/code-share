project_id = "samsung-fridge-dev"   # CHANGE ME
env        = "dev"
region     = "asia-south1"
image_repo = "asia-south1-docker.pkg.dev/samsung-fridge-dev/pipeline"
# alert_notification_channels = ["projects/samsung-fridge-dev/notificationChannels/123"]
