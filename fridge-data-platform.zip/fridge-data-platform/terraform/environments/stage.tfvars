project_id = "samsung-fridge-stage"   # CHANGE ME
env        = "stage"
region     = "asia-south1"
image_repo = "asia-south1-docker.pkg.dev/samsung-fridge-stage/pipeline"
# alert_notification_channels = ["projects/samsung-fridge-stage/notificationChannels/123"]
