terraform {
  required_version = ">= 1.7"
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 6.0"
    }
  }
  # Recommended: GCS backend per environment (create the bucket once, manually)
  # backend "gcs" {
  #   bucket = "TF_STATE_BUCKET"
  #   prefix = "fridge-data-platform"
  # }
}

provider "google" {
  project = var.project_id
  region  = var.region
}
