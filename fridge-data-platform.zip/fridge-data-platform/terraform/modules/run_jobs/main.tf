variable "project_id" { type = string }
variable "region" { type = string }
variable "env" { type = string }
variable "image_repo" { type = string }
variable "data_bucket" { type = string }

resource "google_service_account" "pipeline" {
  account_id   = "fridge-pipeline"
  display_name = "Fridge data platform pipeline"
}

# Only the pipeline SA touches bronze; analysts get gold-only IAM elsewhere
resource "google_project_iam_member" "pipeline_roles" {
  for_each = toset([
    "roles/bigquery.jobUser",
    "roles/bigquery.dataEditor",
    "roles/storage.objectAdmin",
    "roles/logging.logWriter",
  ])
  project = var.project_id
  role    = each.value
  member  = "serviceAccount:${google_service_account.pipeline.email}"
}

locals {
  jobs = {
    validator  = { timeout = "1800s", memory = "1Gi" }
    loader     = { timeout = "1800s", memory = "512Mi" }
    dbt-build  = { timeout = "3600s", memory = "1Gi" }
    enrichment = { timeout = "3600s", memory = "2Gi" }
    erasure    = { timeout = "3600s", memory = "512Mi" }
  }
}

resource "google_cloud_run_v2_job" "job" {
  for_each = local.jobs
  name     = "fridge-${each.key}"
  location = var.region

  template {
    template {
      service_account = google_service_account.pipeline.email
      timeout         = each.value.timeout
      max_retries     = 2
      containers {
        image = "${var.image_repo}/${each.key}:latest"
        resources {
          limits = { memory = each.value.memory, cpu = "1" }
        }
        env {
          name  = "GCP_PROJECT"
          value = var.project_id
        }
        env {
          name  = "DATA_BUCKET"
          value = var.data_bucket
        }
        env {
          name  = "ENV"
          value = var.env
        }
      }
    }
  }
}

output "pipeline_sa_email" { value = google_service_account.pipeline.email }
output "job_names" { value = { for k, j in google_cloud_run_v2_job.job : k => j.name } }
