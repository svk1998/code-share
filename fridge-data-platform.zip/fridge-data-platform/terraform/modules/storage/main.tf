variable "project_id" { type = string }
variable "region" { type = string }
variable "env" { type = string }
variable "raw_archive_delete_after_days" { type = number }

# One data bucket, prefixes carry meaning:
#   landing/    incoming batches from SmartThings (short-lived)
#   raw/        validated immutable archive: raw/device_id=X/date=YYYY-MM-DD/
#   quarantine/ contract-violating files (DLQ)
resource "google_storage_bucket" "data" {
  name                        = "${var.project_id}-fridge-data"
  location                    = var.region # regional: multi-region is ~2x cost for no benefit
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"

  versioning { enabled = false }

  # landing/ files are transient: validator moves them within the hour
  lifecycle_rule {
    action { type = "Delete" }
    condition {
      age            = 7
      matches_prefix = ["landing/"]
    }
  }

  # raw/ archive rides down the storage classes, then deletes after N years
  lifecycle_rule {
    action {
      type          = "SetStorageClass"
      storage_class = "NEARLINE"
    }
    condition {
      age            = 30
      matches_prefix = ["raw/"]
    }
  }
  lifecycle_rule {
    action {
      type          = "SetStorageClass"
      storage_class = "COLDLINE"
    }
    condition {
      age            = 90
      matches_prefix = ["raw/"]
    }
  }
  lifecycle_rule {
    action {
      type          = "SetStorageClass"
      storage_class = "ARCHIVE"
    }
    condition {
      age            = 365
      matches_prefix = ["raw/"]
    }
  }
  lifecycle_rule {
    action { type = "Delete" }
    condition {
      age            = var.raw_archive_delete_after_days
      matches_prefix = ["raw/"]
    }
  }

  # quarantine kept 90 d for triage
  lifecycle_rule {
    action { type = "Delete" }
    condition {
      age            = 90
      matches_prefix = ["quarantine/"]
    }
  }

  labels = { env = var.env, system = "fridge-data-platform" }
}

output "data_bucket" { value = google_storage_bucket.data.name }
