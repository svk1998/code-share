variable "project_id" { type = string }
variable "region" { type = string }
variable "env" { type = string }
variable "pipeline_sa_email" { type = string }
variable "run_job_names" { type = map(string) }

resource "google_project_iam_member" "wf_runs_jobs" {
  project = var.project_id
  role    = "roles/run.developer"
  member  = "serviceAccount:${var.pipeline_sa_email}"
}

resource "google_workflows_workflow" "pipeline" {
  name            = "fridge-pipeline"
  region          = var.region
  service_account = var.pipeline_sa_email
  source_contents = file("${path.module}/../../../workflows/pipeline.yaml")
  labels          = { env = var.env }
}

# Main pipeline every 4 hours - matches device batching cadence
resource "google_cloud_scheduler_job" "pipeline" {
  name      = "fridge-pipeline-4h"
  region    = var.region
  schedule  = "0 */4 * * *"
  time_zone = "Etc/UTC"
  http_target {
    uri         = "https://workflowexecutions.googleapis.com/v1/projects/${var.project_id}/locations/${var.region}/workflows/${google_workflows_workflow.pipeline.name}/executions"
    http_method = "POST"
    oauth_token { service_account_email = var.pipeline_sa_email }
  }
}

# Nightly erasure job (DPDP/GDPR) - separate cadence from the pipeline
resource "google_cloud_scheduler_job" "erasure" {
  name      = "fridge-erasure-nightly"
  region    = var.region
  schedule  = "0 2 * * *"
  time_zone = "Etc/UTC"
  http_target {
    uri         = "https://run.googleapis.com/v2/projects/${var.project_id}/locations/${var.region}/jobs/${var.run_job_names["erasure"]}:run"
    http_method = "POST"
    oauth_token { service_account_email = var.pipeline_sa_email }
  }
}
