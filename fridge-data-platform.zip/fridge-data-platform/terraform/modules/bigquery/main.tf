variable "project_id" { type = string }
variable "region" { type = string }
variable "env" { type = string }
variable "bronze_partition_expiration_days" { type = number }

locals {
  datasets = {
    bronze = "Raw immutable events, loaded from GCS"
    silver = "Cleaned, deduped, entity-resolved"
    gold   = "Household features, segments, marts"
    ops    = "Pipeline bookkeeping: deletion requests, loaded files, tombstones"
  }
}

resource "google_bigquery_dataset" "ds" {
  for_each      = local.datasets
  dataset_id    = each.key
  location      = var.region
  description   = each.value
  # Compressed JSON events bill 3-5x cheaper under physical billing
  storage_billing_model = "PHYSICAL"
  labels        = { env = var.env, system = "fridge-data-platform" }
}

resource "google_bigquery_table" "raw_events" {
  dataset_id          = google_bigquery_dataset.ds["bronze"].dataset_id
  table_id            = "raw_events"
  deletion_protection = true

  time_partitioning {
    type          = "DAY"
    field         = "captured_at"
    expiration_ms = var.bronze_partition_expiration_days * 24 * 3600 * 1000
  }
  clustering = ["device_id"]

  # Biggest bill risk is a bad ad-hoc query, not the pipeline
  require_partition_filter = true

  schema = jsonencode([
    { name = "event_id", type = "STRING", mode = "REQUIRED",
      description = "hash(device_id, captured_at, item_hash) - idempotency key" },
    { name = "device_id", type = "STRING", mode = "REQUIRED" },
    { name = "schema_version", type = "STRING", mode = "REQUIRED" },
    { name = "event_type", type = "STRING", mode = "REQUIRED",
      description = "item_added | item_removed | level_changed" },
    { name = "captured_at", type = "TIMESTAMP", mode = "REQUIRED" },
    { name = "payload", type = "JSON", mode = "NULLABLE",
      description = "Full L1-L4 recognition payload; schema evolution lives here" },
    { name = "ingested_at", type = "TIMESTAMP", mode = "REQUIRED" },
    { name = "source_file", type = "STRING", mode = "NULLABLE" }
  ])
}

resource "google_bigquery_table" "rejected_events" {
  dataset_id          = google_bigquery_dataset.ds["bronze"].dataset_id
  table_id            = "rejected_events"
  deletion_protection = false
  time_partitioning { type = "DAY" }
  schema = jsonencode([
    { name = "rejected_at", type = "TIMESTAMP", mode = "REQUIRED" },
    { name = "source_file", type = "STRING", mode = "REQUIRED" },
    { name = "line_no", type = "INTEGER", mode = "NULLABLE" },
    { name = "reason", type = "STRING", mode = "REQUIRED" },
    { name = "raw_line", type = "STRING", mode = "NULLABLE" }
  ])
}

resource "google_bigquery_table" "deletion_requests" {
  dataset_id          = google_bigquery_dataset.ds["ops"].dataset_id
  table_id            = "deletion_requests"
  deletion_protection = true
  schema = jsonencode([
    { name = "request_id", type = "STRING", mode = "REQUIRED" },
    { name = "device_id", type = "STRING", mode = "REQUIRED" },
    { name = "requested_at", type = "TIMESTAMP", mode = "REQUIRED" },
    { name = "status", type = "STRING", mode = "REQUIRED",
      description = "pending | done | failed" },
    { name = "completed_at", type = "TIMESTAMP", mode = "NULLABLE" }
  ])
}

resource "google_bigquery_table" "erasure_tombstones" {
  dataset_id          = google_bigquery_dataset.ds["ops"].dataset_id
  table_id            = "erasure_tombstones"
  deletion_protection = true
  schema = jsonencode([
    { name = "device_id_hash", type = "STRING", mode = "REQUIRED",
      description = "SHA256 of device_id - audit proof without retaining the id" },
    { name = "erased_at", type = "TIMESTAMP", mode = "REQUIRED" },
    { name = "layers", type = "STRING", mode = "REPEATED" }
  ])
}

resource "google_bigquery_table" "loaded_files" {
  dataset_id          = google_bigquery_dataset.ds["ops"].dataset_id
  table_id            = "loaded_files"
  deletion_protection = false
  schema = jsonencode([
    { name = "source_file", type = "STRING", mode = "REQUIRED" },
    { name = "loaded_at", type = "TIMESTAMP", mode = "REQUIRED" },
    { name = "row_count", type = "INTEGER", mode = "NULLABLE" }
  ])
}
