variable "project_id" { type = string }
variable "env" { type = string }
variable "notification_channels" { type = list(string) }

# Alert 1: any Cloud Run job execution failure
resource "google_monitoring_alert_policy" "run_job_failed" {
  display_name = "fridge: Cloud Run job failed (${var.env})"
  combiner     = "OR"
  conditions {
    display_name = "Completed executions with failure"
    condition_matched_log {
      filter = <<-EOT
        resource.type="cloud_run_job"
        resource.labels.job_name=~"^fridge-"
        severity>=ERROR
        textPayload=~"(failed|error)"
      EOT
    }
  }
  alert_strategy {
    notification_rate_limit { period = "3600s" }
  }
  notification_channels = var.notification_channels
}

# Alert 2: quarantine growth (log-based metric written by the validator)
resource "google_logging_metric" "quarantined" {
  name   = "fridge_quarantined_files"
  filter = "resource.type=\"cloud_run_job\" jsonPayload.metric=\"quarantined_file\""
}

resource "google_monitoring_alert_policy" "quarantine_spike" {
  display_name = "fridge: quarantine spike (${var.env})"
  combiner     = "OR"
  conditions {
    display_name = "> 10 quarantined files / hour"
    condition_threshold {
      filter          = "metric.type=\"logging.googleapis.com/user/${google_logging_metric.quarantined.name}\" resource.type=\"cloud_run_job\""
      comparison      = "COMPARISON_GT"
      threshold_value = 10
      duration        = "0s"
      aggregations {
        alignment_period   = "3600s"
        per_series_aligner = "ALIGN_SUM"
      }
    }
  }
  notification_channels = var.notification_channels
}

# SLO 2 (completeness) lives as a scheduled BQ assertion in dbt
# (see dbt/models/gold/assert_daily_volume.sql) surfaced through
# the dbt-build job failure alert above.
