module "storage" {
  source                        = "./modules/storage"
  project_id                    = var.project_id
  region                        = var.region
  env                           = var.env
  raw_archive_delete_after_days = var.raw_archive_delete_after_days
}

module "bigquery" {
  source                           = "./modules/bigquery"
  project_id                       = var.project_id
  region                           = var.region
  env                              = var.env
  bronze_partition_expiration_days = var.bronze_partition_expiration_days
}

module "run_jobs" {
  source      = "./modules/run_jobs"
  project_id  = var.project_id
  region      = var.region
  env         = var.env
  image_repo  = var.image_repo
  data_bucket = module.storage.data_bucket
}

module "workflows" {
  source              = "./modules/workflows"
  project_id          = var.project_id
  region              = var.region
  env                 = var.env
  pipeline_sa_email   = module.run_jobs.pipeline_sa_email
  run_job_names       = module.run_jobs.job_names
}

module "monitoring" {
  source                = "./modules/monitoring"
  project_id            = var.project_id
  env                   = var.env
  notification_channels = var.alert_notification_channels
}
