"""Erasure job (DPDP / GDPR right-to-erasure).

Driven by ops.deletion_requests (status='pending'). For each device_id:
  1. DELETE from bronze/silver/gold (BQ physically purges within 7-day
     time-travel window -> 30-day SLA is comfortable)
  2. Delete GCS objects under raw/device_id=<id>/ (prefix delete)
  3. Write a hashed tombstone (audit proof without retaining the id)
  4. Mark the request done

Runs nightly as a Cloud Run Job.
"""
import os
import hashlib
import datetime as dt
from google.cloud import bigquery, storage

PROJECT = os.environ["GCP_PROJECT"]
BUCKET = os.environ["DATA_BUCKET"]

# (table, device column, extra predicate)
# bronze.raw_events sets require_partition_filter = true, so even a DELETE must
# predicate on the partition column. A 1970 floor satisfies BigQuery's
# requirement while still touching every partition -- which erasure must do.
TARGETS = [
    ("bronze.raw_events", "device_id", "captured_at >= TIMESTAMP('1970-01-01')"),
    ("silver.item_events", "device_id", None),
    ("silver.fridge_items", "device_id", None),
    ("gold.household_features", "device_id", None),
]


def main():
    bq = bigquery.Client(project=PROJECT)
    gcs = storage.Client(project=PROJECT)

    pending = list(bq.query(
        f"SELECT request_id, device_id FROM `{PROJECT}.ops.deletion_requests` "
        f"WHERE status = 'pending'"
    ).result())

    now = dt.datetime.now(dt.timezone.utc).isoformat()

    for req in pending:
        dev = req.device_id
        layers = []
        for table, col, extra in TARGETS:
            where = f"{col} = @dev" + (f" AND {extra}" if extra else "")
            bq.query(
                f"DELETE FROM `{PROJECT}.{table}` WHERE {where}",
                job_config=bigquery.QueryJobConfig(
                    query_parameters=[bigquery.ScalarQueryParameter("dev", "STRING", dev)]
                ),
            ).result()
            layers.append(table)

        # GCS prefix delete
        for blob in gcs.list_blobs(BUCKET, prefix=f"raw/device_id={dev}/"):
            blob.delete()
        layers.append("gcs:raw")

        dev_hash = hashlib.sha256(dev.encode()).hexdigest()
        bq.insert_rows_json(
            f"{PROJECT}.ops.erasure_tombstones",
            [{"device_id_hash": dev_hash, "erased_at": now, "layers": layers}],
        )
        bq.query(
            f"UPDATE `{PROJECT}.ops.deletion_requests` "
            f"SET status='done', completed_at=CURRENT_TIMESTAMP() "
            f"WHERE request_id=@rid",
            job_config=bigquery.QueryJobConfig(
                query_parameters=[bigquery.ScalarQueryParameter("rid", "STRING", req.request_id)]
            ),
        ).result()
        print(f"erased device {dev_hash[:12]}... across {len(layers)} layers")

    print(f"processed {len(pending)} deletion requests")


if __name__ == "__main__":
    main()
