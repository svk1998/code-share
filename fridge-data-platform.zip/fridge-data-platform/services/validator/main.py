"""Validator: landing/ -> raw/ (valid) or quarantine/ (contract violation).

Reads gzip JSONL batches under landing/, validates every line against the
JSON Schema matching its schema_version, and routes accordingly. Unknown
schema_version is quarantined and alerted -- never silently dropped.

Runs as a Cloud Run Job (batch). Idempotent: re-processing a landing file
that was already moved is a no-op.
"""
import gzip
import json
import os
import hashlib
import datetime as dt
from pathlib import Path

from google.cloud import storage, bigquery
from jsonschema import Draft202012Validator

PROJECT = os.environ["GCP_PROJECT"]
BUCKET = os.environ["DATA_BUCKET"]

_SCHEMAS = {
    p.name.split(".")[0].replace("event_", ""): Draft202012Validator(json.loads(p.read_text()))
    for p in Path(__file__).parent.glob("contracts/event_*.schema.json")
}


def _event_id(device_id: str, captured_at: str, item: dict) -> str:
    h = hashlib.sha256(
        f"{device_id}|{captured_at}|{json.dumps(item, sort_keys=True)}".encode()
    ).hexdigest()
    return h[:32]


def process_blob(gcs: storage.Client, bq: bigquery.Client, blob: storage.Blob):
    raw = gzip.decompress(blob.download_as_bytes()).decode()
    good, rejected = [], []
    now = dt.datetime.now(dt.timezone.utc).isoformat()

    for i, line in enumerate(raw.splitlines()):
        if not line.strip():
            continue
        try:
            evt = json.loads(line)
        except json.JSONDecodeError as e:
            rejected.append((i, f"invalid json: {e}", line))
            continue

        ver = evt.get("schema_version")
        validator = _SCHEMAS.get(ver)
        if validator is None:
            # log a structured metric line the alert policy watches
            print(json.dumps({"metric": "quarantined_file", "reason": "unknown_schema", "file": blob.name}))
            rejected.append((i, f"unknown schema_version: {ver}", line))
            continue

        errs = sorted(validator.iter_errors(evt), key=lambda e: e.path)
        if errs:
            rejected.append((i, "; ".join(e.message for e in errs[:3]), line))
            continue

        evt.setdefault("event_id", _event_id(evt["device_id"], evt["captured_at"], evt["payload"]))
        evt["ingested_at"] = now
        evt["source_file"] = blob.name
        # payload stored as JSON string column
        evt["payload"] = json.dumps(evt["payload"])
        good.append(evt)

    bucket = gcs.bucket(BUCKET)

    if good:
        # write validated NDJSON to raw/device_id=.../date=.../ for prefix-based erasure
        by_device = {}
        for e in good:
            day = e["captured_at"][:10]
            key = f"raw/device_id={e['device_id']}/date={day}/{Path(blob.name).stem}.ndjson"
            by_device.setdefault(key, []).append(json.dumps(e))
        for key, lines in by_device.items():
            bucket.blob(key).upload_from_string("\n".join(lines), content_type="application/x-ndjson")

    if rejected:
        rows = [
            {"rejected_at": now, "source_file": blob.name, "line_no": ln, "reason": r, "raw_line": raw_line[:2000]}
            for ln, r, raw_line in rejected
        ]
        bq.insert_rows_json(f"{PROJECT}.bronze.rejected_events", rows)
        # copy the offending file to quarantine/ for triage
        bucket.copy_blob(blob, bucket, f"quarantine/{Path(blob.name).name}")

    # remove the processed landing file (idempotent: gone -> nothing to do)
    blob.delete()
    print(json.dumps({"file": blob.name, "valid": len(good), "rejected": len(rejected)}))


def main():
    gcs = storage.Client(project=PROJECT)
    bq = bigquery.Client(project=PROJECT)
    blobs = list(gcs.list_blobs(BUCKET, prefix="landing/"))
    for blob in blobs:
        if blob.name.endswith("/"):
            continue
        process_blob(gcs, bq, blob)
    print(json.dumps({"processed_files": len(blobs)}))


if __name__ == "__main__":
    main()
