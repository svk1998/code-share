"""Loader: raw/*.ndjson -> bronze.raw_events via a free BigQuery LOAD JOB.

Load jobs cost nothing (no streaming/ingestion fees). We track loaded files
in ops.loaded_files so a re-run never double-loads. event_id dedup in silver
is the second safety net.
"""
import os
import datetime as dt
from google.cloud import bigquery, storage

PROJECT = os.environ["GCP_PROJECT"]
BUCKET = os.environ["DATA_BUCKET"]


def already_loaded(bq: bigquery.Client) -> set[str]:
    rows = bq.query(
        f"SELECT source_file FROM `{PROJECT}.ops.loaded_files`"
    ).result()
    return {r.source_file for r in rows}


def main():
    bq = bigquery.Client(project=PROJECT)
    gcs = storage.Client(project=PROJECT)

    loaded = already_loaded(bq)
    uris, files = [], []
    for blob in gcs.list_blobs(BUCKET, prefix="raw/"):
        if blob.name.endswith(".ndjson") and blob.name not in loaded:
            uris.append(f"gs://{BUCKET}/{blob.name}")
            files.append(blob.name)

    if not uris:
        print("nothing new to load")
        return

    job_config = bigquery.LoadJobConfig(
        source_format=bigquery.SourceFormat.NEWLINE_DELIMITED_JSON,
        write_disposition=bigquery.WriteDisposition.WRITE_APPEND,
        ignore_unknown_values=False,
        schema_update_options=[bigquery.SchemaUpdateOption.ALLOW_FIELD_ADDITION],
    )
    # Load in batches of 10k URIs (BQ per-job limit is high; keep it simple)
    load_job = bq.load_table_from_uri(
        uris, f"{PROJECT}.bronze.raw_events", job_config=job_config
    )
    load_job.result()

    now = dt.datetime.now(dt.timezone.utc).isoformat()
    bq.insert_rows_json(
        f"{PROJECT}.ops.loaded_files",
        [{"source_file": f, "loaded_at": now, "row_count": None} for f in files],
    )
    print(f"loaded {len(uris)} files, {load_job.output_rows} rows")


if __name__ == "__main__":
    main()
