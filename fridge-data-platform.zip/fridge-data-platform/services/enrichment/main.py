"""Product resolution ladder: raw L3/L4 strings -> canonical products.

Cost control is the whole point. Each unresolved string tries, in order:
  1. exact-match cache   (silver.product_catalog, already-resolved strings)
  2. vector similarity   (BQ VECTOR_SEARCH against resolved catalog / OFF)
  3. LLM batch           (only true novelties; Gemini Flash Batch or vLLM)

Resolutions are written back so tomorrow's identical string is a cache hit.
Every row carries confidence + resolved_by provenance; low-confidence rows
route to review and never flow silently into gold.

This file is a runnable skeleton -- the vector + LLM calls are stubbed with
clear extension points so it can run end-to-end on synthetic data first.
"""
import os
import json
import datetime as dt
from google.cloud import bigquery

PROJECT = os.environ["GCP_PROJECT"]
CONF_THRESHOLD = float(os.environ.get("RESOLVE_CONF_THRESHOLD", "0.6"))


def _raw_key(brand: str | None, text: dict | None, l2: str) -> str:
    parts = [brand or "", (text or {}).get("name", "") if text else "", l2]
    return "|".join(p.strip().lower() for p in parts)


def fetch_unresolved(bq: bigquery.Client) -> list[dict]:
    sql = f"""
    SELECT DISTINCT
      JSON_VALUE(payload, '$.l3_brand') AS brand,
      JSON_VALUE(payload, '$.l2_type')  AS l2_type,
      payload
    FROM `{PROJECT}.bronze.raw_events`
    WHERE captured_at >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
      AND NOT EXISTS (
        SELECT 1 FROM `{PROJECT}.silver.product_catalog` c
        WHERE c.raw_key = LOWER(CONCAT(
          IFNULL(JSON_VALUE(payload,'$.l3_brand'),''), '|',
          IFNULL(JSON_VALUE(payload,'$.l4_text.name'),''), '|',
          JSON_VALUE(payload,'$.l2_type')))
      )
    LIMIT 5000
    """
    return [dict(r) for r in bq.query(sql).result()]


# --- ladder rungs -----------------------------------------------------------

def resolve_vector(raw_key: str) -> dict | None:
    """Rung 2. TODO: BQ VECTOR_SEARCH over an embeddings table built from the
    resolved catalog + Open Food Facts India dump. Return best match above a
    similarity floor, else None."""
    return None


def resolve_llm(batch: list[str]) -> dict[str, dict]:
    """Rung 3. TODO: submit as a Gemini Flash Batch job (-50%) or call the
    self-hosted vLLM endpoint. Prompt returns strict JSON:
      {canonical_product, brand, nova_group, nutri_score, estimated: bool}
    Only novelties reach here; keep the batch small."""
    return {}


def main():
    bq = bigquery.Client(project=PROJECT)
    now = dt.datetime.now(dt.timezone.utc).isoformat()
    rows = fetch_unresolved(bq)

    resolved, llm_batch, key_meta = [], [], {}
    for r in rows:
        payload = json.loads(r["payload"]) if isinstance(r["payload"], str) else r["payload"]
        key = _raw_key(r.get("brand"), payload.get("l4_text"), r["l2_type"])
        key_meta[key] = (r.get("brand"), r["l2_type"])

        hit = resolve_vector(key)
        if hit and hit.get("confidence", 0) >= CONF_THRESHOLD:
            resolved.append({**hit, "raw_key": key, "resolved_by": "vector", "resolved_at": now})
        else:
            llm_batch.append(key)

    for key, res in resolve_llm(llm_batch).items():
        brand, l2 = key_meta.get(key, (None, None))
        resolved.append({
            "raw_key": key,
            "canonical_product_id": res.get("canonical_product"),
            "brand": brand,
            "l2_type": l2,
            "nova_group": res.get("nova_group"),
            "nutri_score": res.get("nutri_score"),
            "estimated": res.get("estimated", True),
            "confidence": res.get("confidence", 0.5),
            "resolved_by": "llm",
            "resolved_at": now,
        })

    if resolved:
        errors = bq.insert_rows_json(f"{PROJECT}.silver.product_catalog", resolved)
        if errors:
            raise RuntimeError(f"write-back failed: {errors}")

    # cache-hit rate is a first-class KPI
    total = len(rows) or 1
    novelties = len(llm_batch)
    print(json.dumps({
        "unresolved_seen": len(rows),
        "sent_to_llm": novelties,
        "cache_or_vector_hit_rate": round(1 - novelties / total, 4),
        "written_back": len(resolved),
    }))


if __name__ == "__main__":
    main()
